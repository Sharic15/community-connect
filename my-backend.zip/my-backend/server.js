const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const userRoutes = require('./routes/userRoutes'); // Adjust the path as needed
const projectRoutes = require('./routes/projectRoutes'); // Adjust the path as needed

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());

// Connect to SQLite
const db = new sqlite3.Database('./my-backend.db', (err) => {
    if (err) {
        console.error('Error connecting to SQLite:', err.message);
    } else {
        console.log('Connected to SQLite database');
        // Create the users table if it doesn't exist
        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )
        `, (err) => {
            if (err) {
                console.error('Error creating users table:', err.message);
            } else {
                console.log('Users table is ready');
            }
        });
    }
});

// Pass the database connection to routes
app.use((req, res, next) => {
    req.db = db;
    next();
});

// Use routes
app.use('/api/users', userRoutes);
app.use('/api/projects', projectRoutes);

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
