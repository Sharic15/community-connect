const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../models/user'); 
const router = express.Router();

// Register route
router.post('/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = new User({ name, email, password: hashedPassword });
        await user.save();
        res.status(201).send({ message: 'User registered successfully', user });
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

// Login route
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validate input
        if (!email || !password) {
            return res.status(400).send({ error: 'Email and password are required' });
        }

        // Find user by email
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).send({ error: 'Invalid email or password' });
        }

        // Validate password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).send({ error: 'Invalid email or password' });
        }

        // Successful login
        res.status(200).send({ message: 'Login successful', user: { id: user._id, name: user.name, email: user.email } });
    } catch (error) {
        res.status(500).send({ error: 'Internal server error' });
    }
});

module.exports = router;