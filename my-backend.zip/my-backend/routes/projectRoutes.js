const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

//project schema
const projectSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    createdBy: { type: String, required: true }, // Admin who created the project
    applicants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }] // Users who applied
});

const Project = mongoose.model('Project', projectSchema);

// Admin: Add a project
router.post('/add', async (req, res) => {
    try {
        const { title, description, createdBy } = req.body;

        if (!title || !description || !createdBy) {
            return res.status(400).send({ error: 'All fields are required' });
        }

        const project = new Project({ title, description, createdBy });
        await project.save();
        res.status(201).send({ message: 'Project added successfully', project });
    } catch (error) {
        res.status(500).send({ error: 'Internal server error' });
    }
});

// Admin: Edit a project
router.put('/edit/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { title, description } = req.body;

        const project = await Project.findByIdAndUpdate(
            id,
            { title, description },
            { new: true, runValidators: true }
        );

        if (!project) {
            return res.status(404).send({ error: 'Project not found' });
        }

        res.status(200).send({ message: 'Project updated successfully', project });
    } catch (error) {
        res.status(500).send({ error: 'Internal server error' });
    }
});

// User: Apply for a project
router.post('/apply/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { userId } = req.body;

        if (!userId) {
            return res.status(400).send({ error: 'User ID is required' });
        }

        const project = await Project.findById(id);
        if (!project) {
            return res.status(404).send({ error: 'Project not found' });
        }

        // Add the user to the applicants list if not already applied
        if (!project.applicants.includes(userId)) {
            project.applicants.push(userId);
            await project.save();
        }

        res.status(200).send({ message: 'Applied to project successfully', project });
    } catch (error) {
        res.status(500).send({ error: 'Internal server error' });
    }
});

module.exports = router;