import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectService } from '../project.service';

@Component({
  selector: 'app-volunteer-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './volunteer-dashboard.component.html',
  styleUrls: ['./volunteer-dashboard.component.css'],
})
export class VolunteerDashboardComponent implements OnInit {
  projects: any[] = [];
  appliedProjects: any[] = [];
  skillsFilter: string = '';
  locationFilter: string = '';
  statusFilter: string = '';

  constructor(private projectService: ProjectService) {}

  ngOnInit() {
    this.loadProjects();
    this.appliedProjects = this.projectService.getAppliedProjects();
  }

  loadProjects() {
    this.projects = this.projectService
      .filterBySkillsAndLocation(this.skillsFilter, this.locationFilter)
      .filter(project => this.statusFilter ? project.status === this.statusFilter : true);
  }

  applyForProject(project: any) {
    if (this.appliedProjects.find(p => p.id === project.id)) {
      alert('You have already applied for this project!');
      return;
    }

    this.appliedProjects.push(project);
    this.projectService.addAppliedProject(project);

    // Generate WhatsApp message
    const volunteerPhoneNumber = '6300594119'; // Replace with the volunteer's phone number
    const message = `Dear Volunteer, you have successfully applied for the project "${project.name}" with the required skills: ${project.skills}.`;
    const whatsappLink = `https://wa.me/${volunteerPhoneNumber}?text=${encodeURIComponent(message)}`;

    // Open WhatsApp link
    window.open(whatsappLink, '_blank');

    alert(`You have successfully applied for the project: ${project.name}`);
  }

  filterProjects(event: Event) {
    const selectElement = event.target as HTMLSelectElement;
    this.statusFilter = selectElement.value;
    this.loadProjects();
  }

  filterBySkills(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    this.skillsFilter = inputElement.value;
    this.loadProjects();
  }

  filterByLocation(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    this.locationFilter = inputElement.value;
    this.loadProjects();
  }
}
