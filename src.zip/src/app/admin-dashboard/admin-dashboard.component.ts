// import { Component, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { ProjectService } from '../project.service';

// @Component({
//   selector: 'app-admin-dashboard',
//   standalone: true,
//   imports: [CommonModule, FormsModule],
//   templateUrl: './admin-dashboard.component.html',
//   styleUrls: ['./admin-dashboard.component.css']
// })
// export class AdminDashboardComponent implements OnInit {
//   projects: any[] = [];

//   newProject = {
//     id: 0,
//     name: '',
//     status: '',
//     skills: '',
//     location: ''
//   };

//   isEditMode: boolean = false;
//   editingIndex: number | null = null;

//   constructor(private projectService: ProjectService) {}

//   ngOnInit() {
//     this.projects = this.projectService.getProjects();
//   }

//   addProject() {
//     if (!this.newProject.name.trim()) {
//       alert('Project name is required!');
//       return;
//     }

//     if (this.isEditMode && this.editingIndex !== null) {
//       // Update existing project
//       this.projects[this.editingIndex] = { ...this.newProject };
//       this.cancelEdit();
//     } else {
//       // Add new project
//       this.newProject.id = this.projects.length + 1;
//       this.projectService.addProject({ ...this.newProject });
//     }

//     // Refresh and reset
//     this.projects = this.projectService.getProjects();
//     this.resetForm();
//   }

//   editProject(index: number) {
//     this.isEditMode = true;
//     this.editingIndex = index;
//     this.newProject = { ...this.projects[index] };
//   }

//   cancelEdit() {
//     this.isEditMode = false;
//     this.editingIndex = null;
//     this.resetForm();
//   }

//   resetForm() {
//     this.newProject = {
//       id: 0,
//       name: '',
//       status: '',
//       skills: '',
//       location: ''
//     };
//   }
// }

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProjectService } from '../project.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  projects: any[] = [];
  newProject = { id: 0, name: '', status: 'In Progress', skills: '', location: '' };

  isEditMode: boolean = false;
  editingIndex: number | null = null;

  constructor(private projectService: ProjectService) {}

  ngOnInit() {
    this.projects = this.projectService.getProjects(); // Get the projects from the service
  }

  addProject() {
    if (!this.newProject.name.trim()) {
      alert('Project name is required!');
      return;
    }

    if (this.isEditMode && this.editingIndex !== null) {
      // Update existing project
      this.projects[this.editingIndex] = { ...this.newProject };
      this.projectService.updateProject(this.newProject.id, this.newProject); // Update project in the service
      this.cancelEdit();
    } else {
      // Add new project
      this.newProject.id = this.projects.length + 1; // Assign ID based on length
      this.projectService.addProject(this.newProject); // Add project to the service
    }

    // Refresh and reset
    this.projects = this.projectService.getProjects(); // Get the updated projects list
    this.resetForm();
  }

  editProject(index: number) {
    this.isEditMode = true;
    this.editingIndex = index;
    this.newProject = { ...this.projects[index] }; // Populate the form with existing project data
  }

  cancelEdit() {
    this.isEditMode = false;
    this.editingIndex = null;
    this.resetForm();
  }

  resetForm() {
    this.newProject = { id: 0, name: '', status: 'In Progress', skills: '', location: '' }; // Reset form for new project
  }
}
