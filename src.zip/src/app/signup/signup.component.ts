import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  user = {
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  };

  constructor(private router: Router) {}

  onSubmit() {
    if (this.user.password !== this.user.confirmPassword) {
      alert('Passwords do not match!');
      return;
    }

    // Save user data to localStorage
    localStorage.setItem('volunteer', JSON.stringify({
      email: this.user.email,
      password: this.user.password
    }));

    console.log('User registered:', this.user);
    alert('Registration successful! Please log in.');
    this.router.navigate(['/login']); // Redirect to login page
  }
}
