import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';  // Add FormsModule here

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],  // Add FormsModule to imports
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginSuccess: boolean = false;

  credentials = {
    emailOrUserId: '',
    password: '',
    role: 'volunteer'  // Default role (can be changed if needed)
  };

  // Hardcoded admin credentials
  adminCredentials = {
    emailOrUserId: 'admin@admin.com',
    password: 'admin123',
  };

  constructor(private router: Router) {}

  onSubmit(event: Event, emailOrUserId: string, password: string, role: string) {
    event.preventDefault(); // Prevent default form submission

    if (role === 'admin') {
      if (
        emailOrUserId === this.adminCredentials.emailOrUserId &&
        password === this.adminCredentials.password
      ) {
        console.log('Login successful for admin');
        this.router.navigate(['/admin-dashboard']); // Navigate to Admin Dashboard
      } else {
        alert('Invalid admin credentials. Please try again.');
      }
    } else if (role === 'volunteer') {
      // Check volunteer credentials from localStorage
      const storedVolunteer = localStorage.getItem('volunteer');

      if (storedVolunteer) {
        const volunteer = JSON.parse(storedVolunteer);

        if (
          emailOrUserId === volunteer.email &&
          password === volunteer.password
        ) {
          console.log('Login successful for volunteer');
          this.router.navigate(['/home']); // Navigate to Volunteer Dashboard
        } else {
          alert('Invalid volunteer credentials. Please try again.');
        }
      } else {
        alert('No volunteer data found. Please sign up first.');
      }
    }
  }
}
