import { Injectable } from '@angular/core';
import * as Twilio from 'twilio';

@Injectable({
  providedIn: 'root',
})
export class WhatsAppService {
  private accountSid = 'your_account_sid'; // Replace with your Twilio Account SID
  private authToken = 'your_auth_token'; // Replace with your Twilio Auth Token
  private twilioNumber = 'whatsapp:+916300594119'; // Replace with your Twilio WhatsApp Number
  private client: Twilio.Twilio;

  constructor() {
    this.client = new Twilio.Twilio(this.accountSid, this.authToken);
  }

  sendWhatsAppMessage(to: string, message: string) {
    return this.client.messages.create({
      from: this.twilioNumber,
      to: `whatsapp:${to}`,
      body: message,
    });
  }
}
