// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class ProjectService {
//   private projectsKey = 'community-connect-projects';
//   private appliedProjectsKey = 'community-connect-applied-projects';

//   getProjects(): any[] {
//     const stored = localStorage.getItem(this.projectsKey);
//     return stored ? JSON.parse(stored) : [];
//   }

//   addProject(project: any): void {
//     const projects = this.getProjects();
//     projects.push(project);
//     localStorage.setItem(this.projectsKey, JSON.stringify(projects));
//     console.log('✅ Project added:', project);
//   }

//   updateProject(id: number, updatedProject: any): void {
//     const projects = this.getProjects();
//     const index = projects.findIndex(p => p.id === id);
//     if (index !== -1) {
//       projects[index] = { ...projects[index], ...updatedProject };
//       localStorage.setItem(this.projectsKey, JSON.stringify(projects));
//       console.log('✅ Project updated:', updatedProject);
//     } else {
//       console.error('❌ Project not found with ID:', id);
//     }
//   }

//   filterByStatus(status: string): any[] {
//     return this.getProjects().filter(project => project.status === status);
//   }

//   filterBySkillsAndLocation(skills: string, location: string): any[] {
//     return this.getProjects().filter(project => {
//       const skillMatch = !skills || project.skills?.toLowerCase().includes(skills.toLowerCase());
//       const locationMatch = !location || project.location?.toLowerCase().includes(location.toLowerCase());
//       return skillMatch && locationMatch;
//     });
//   }

//   // ✅ Applied Projects Storage
//   getAppliedProjects(): any[] {
//     const stored = localStorage.getItem(this.appliedProjectsKey);
//     return stored ? JSON.parse(stored) : [];
//   }

//   addAppliedProject(project: any): void {
//     const applied = this.getAppliedProjects();
//     applied.push(project);
//     localStorage.setItem(this.appliedProjectsKey, JSON.stringify(applied));
//   }
// }
import { Injectable, inject } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  private projectsKey = 'community-connect-projects';
  private appliedProjectsKey = 'community-connect-applied-projects';

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  getProjects(): any[] {
    if (!this.isBrowser()) return [];
    const stored = localStorage.getItem(this.projectsKey);
    return stored ? JSON.parse(stored) : [];
  }

  addProject(project: any): void {
    if (!this.isBrowser()) return;
    const projects = this.getProjects();
    projects.push(project);
    localStorage.setItem(this.projectsKey, JSON.stringify(projects));
    console.log('✅ Project added:', project);
  }

  updateProject(id: number, updatedProject: any): void {
    if (!this.isBrowser()) return;
    const projects = this.getProjects();
    const index = projects.findIndex(p => p.id === id);
    if (index !== -1) {
      projects[index] = { ...projects[index], ...updatedProject };
      localStorage.setItem(this.projectsKey, JSON.stringify(projects));
      console.log('✅ Project updated:', updatedProject);
    } else {
      console.error('❌ Project not found with ID:', id);
    }
  }

  filterByStatus(status: string): any[] {
    return this.getProjects().filter(project => project.status === status);
  }

  filterBySkillsAndLocation(skills: string, location: string): any[] {
    return this.getProjects().filter(project => {
      const skillMatch = !skills || project.skills?.toLowerCase().includes(skills.toLowerCase());
      const locationMatch = !location || project.location?.toLowerCase().includes(location.toLowerCase());
      return skillMatch && locationMatch;
    });
  }

  getAppliedProjects(): any[] {
    if (!this.isBrowser()) return [];
    const stored = localStorage.getItem(this.appliedProjectsKey);
    return stored ? JSON.parse(stored) : [];
  }

  addAppliedProject(project: any): void {
    if (!this.isBrowser()) return;
    const applied = this.getAppliedProjects();
    applied.push(project);
    localStorage.setItem(this.appliedProjectsKey, JSON.stringify(applied));
  }
}
