import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  addUser(user: { name: string; email: string; password: string, role: string }) {
    // Storing the volunteer user in localStorage
    localStorage.setItem('volunteer', JSON.stringify(user));
    console.log('User added:', user);
  }

  getUser() {
    return JSON.parse(localStorage.getItem('volunteer') || '{}');
  }
}
